import React from "react";

const Outlet = () => {
  return <div>Outlet</div>;
};

export default Outlet;
