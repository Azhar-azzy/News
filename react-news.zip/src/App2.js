import logo from "./logo.svg";
import "./App.css";
import Navbar from "./components/Navbar";
import { useEffect, useState } from "react";

function App() {
  const [headlines, setHeadlines] = useState([]);

  const fetchTopHeadlines = async () => {
    try {
      const response = await fetch(
        "https://api.nytimes.com/svc/search/v2/articlesearch.json?q=election&api-key=AG0YmjIthQ6x99FNvc14CE8KQf6H3jKA",
        {
          method: "GET",
        }
      );
      const data = await response.json();
      console.log(data.response.docs);
      setHeadlines(data.response.docs);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchTopHeadlines();
    // eslint-disable-next-line
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <ul>
          {headlines &&
            headlines.map((data) => {
              let imageurl =
                data.multimedia.length > 0
                  ? `https://www.nytimes.com/${data.multimedia[0].url}`
                  : "https://www.ultimatesource.toys/wp-content/uploads/2013/11/dummy-image-square-1.jpg";
              return (
                <li key={data.abstract}>
                  <img src={imageurl} alt="article" height={100} />
                  {data.abstract}
                </li>
              );
            })}
        </ul>
        <Navbar />
      </header>
    </div>
  );
}

export default App;
